package ventanas;


import javax.swing.JOptionPane;


import java.sql.*;
public class usuario extends javax.swing.JFrame {

    
private Connection conexion;     
private Statement st;     
private ResultSet rs;

    public usuario() {
        initComponents();
        Conectar();
    }
    
                    public void Conectar(){

                     try{ 
                        conexion=DriverManager.getConnection("jdbc:mysql://localhost:3307/protaller","root","");                     
                        st=conexion.createStatement(); 

                        rs=st.executeQuery("Select * from usuarios");             

                        rs.first();
                        this.jTF_usuario.setText(rs.getString("usuario"));                         
                        this.jTF_contrasena.setText(rs.getString("clave")); 
                        
                        }catch(SQLException ex){ 
                         
                    } 

                }
                    public void Ingresar() {        
                     try{ 
                           
                       String usuario=this.jTF_usuario.getText(); 
                       String contrasena=new String(this.jTF_contrasena.getText()); 
                       String sql="select * from  usuarios where usuario= '"+usuario+"' and clave ='"+contrasena+"';";
                     
                     rs=st.executeQuery(sql);
                     
                     if(rs.next()){
                         
                         Administrador login = new Administrador();
                         login.setVisible(true);
                         JOptionPane.showMessageDialog(this, "Bienvenido");
                     }
                     
                     else{
                         JOptionPane.showMessageDialog(this, "Usuario Incorrecto");
                     }
                 }
                    catch(SQLException ex) { 
                     JOptionPane.showMessageDialog(null, "Error 001" + ex.getMessage());
                }
                    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jL_usuario = new javax.swing.JLabel();
        jL_contrasena = new javax.swing.JLabel();
        jTF_usuario = new javax.swing.JTextField();
        jTF_contrasena = new javax.swing.JTextField();
        jB_ingresar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jB_cambiar_contrasena = new javax.swing.JButton();
        jL_imagen = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 153));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 204)));
        jPanel1.setForeground(new java.awt.Color(102, 204, 255));
        jPanel1.setDoubleBuffered(false);

        jL_usuario.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_usuario.setForeground(new java.awt.Color(255, 255, 255));
        jL_usuario.setText("Usuario");

        jL_contrasena.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_contrasena.setForeground(new java.awt.Color(255, 255, 255));
        jL_contrasena.setText("Contraseña");

        jTF_usuario.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_usuario.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jTF_contrasena.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_contrasena.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_ingresar.setBackground(new java.awt.Color(0, 0, 51));
        jB_ingresar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_ingresar.setForeground(new java.awt.Color(255, 255, 255));
        jB_ingresar.setText("Ingresar");
        jB_ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_ingresarActionPerformed(evt);
            }
        });

        jLabel3.setBackground(new java.awt.Color(0, 255, 0));
        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 102, 0));
        jLabel3.setText("USUARIO");

        jB_cambiar_contrasena.setBackground(new java.awt.Color(0, 0, 51));
        jB_cambiar_contrasena.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_cambiar_contrasena.setForeground(new java.awt.Color(255, 255, 255));
        jB_cambiar_contrasena.setText("Salir");
        jB_cambiar_contrasena.setToolTipText("\n\n");

        jL_imagen.setIcon(new javax.swing.ImageIcon("C:\\Users\\Jireh Castillo\\Pictures\\loginjpg2.png")); // NOI18N

        jSeparator3.setBackground(new java.awt.Color(0, 51, 255));
        jSeparator3.setForeground(new java.awt.Color(51, 153, 255));
        jSeparator3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 51), new java.awt.Color(0, 51, 255), new java.awt.Color(0, 0, 153)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(114, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTF_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF_contrasena, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(jL_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jL_contrasena))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jB_cambiar_contrasena, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jB_ingresar)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jL_imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))))
            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel3)
                .addGap(3, 3, 3)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jL_usuario)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTF_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jL_contrasena)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTF_contrasena, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jL_imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jB_cambiar_contrasena, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jB_ingresar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jB_ingresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ingresarActionPerformed
        Ingresar();
        
         
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_ingresarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(usuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new usuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jB_cambiar_contrasena;
    private javax.swing.JButton jB_ingresar;
    private javax.swing.JLabel jL_contrasena;
    private javax.swing.JLabel jL_imagen;
    private javax.swing.JLabel jL_usuario;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTF_contrasena;
    private javax.swing.JTextField jTF_usuario;
    // End of variables declaration//GEN-END:variables
}
