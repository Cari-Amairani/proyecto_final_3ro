package ventanas;


import javax.swing.JOptionPane;



import java.sql.*;
public class empleados extends javax.swing.JFrame {
    
private Connection conexion;     
private Statement st;     
private ResultSet rs; 

    public empleados() {
        initComponents();
        Conectar();
    }
     public void Conectar(){

                     try{ 
                        conexion=DriverManager.getConnection("jdbc:mysql://localhost:3307/protaller","root","");                     
                        st=conexion.createStatement(); 

                        rs=st.executeQuery("Select * from empleados");             

                        rs.first(); 

            this.jTF_rfc.setText(rs.getString("RFC"));                         
            this.jTF_nombre_empleado.setText(rs.getString("Nombre"));             
            this.jTF_apellido_empleado.setText(rs.getString("Ap_Paterno"));
            this.jTF_telefono_empleado.setText(rs.getString("Telefono")); 
            this.jTF_direccion_empleado.setText(rs.getString("Direccion"));
            this.jTF_ciudad_empleado.setText(rs.getString("Ciudad")); 
            this.jTF_fecha.setText(rs.getString("Fe_Ingreso"));
            
                    }catch(SQLException err){ 
                         
                    } 

                }
                private void siguienteRegistro(){    
                    try{            
                    if(rs.isLast()==false) {   
                     rs.next();               
                     this.jTF_rfc.setText(rs.getString("RFC"));                         
                     this.jTF_nombre_empleado.setText(rs.getString("Nombre"));             
                     this.jTF_apellido_empleado.setText(rs.getString("Ap_Paterno"));
                     this.jTF_telefono_empleado.setText(rs.getString("Telefono")); 
                     this.jTF_direccion_empleado.setText(rs.getString("Direccion"));
                     this.jTF_ciudad_empleado.setText(rs.getString("Ciudad")); 
                     this.jTF_fecha.setText(rs.getString("Fe_Ingreso"));
             }        
            }catch(Exception err) {   
             }    
            }
                private void anteriorRegistro(){    
                        try{            
     
                        rs.previous();               
                        this.jTF_rfc.setText(rs.getString("RFC"));                         
                        this.jTF_nombre_empleado.setText(rs.getString("Nombre"));             
                        this.jTF_apellido_empleado.setText(rs.getString("Ap_Paterno"));
                        this.jTF_telefono_empleado.setText(rs.getString("Telefono")); 
                        this.jTF_direccion_empleado.setText(rs.getString("Direccion"));
                        this.jTF_ciudad_empleado.setText(rs.getString("Ciudad")); 
                        this.jTF_fecha.setText(rs.getString("Fe_Ingreso"));
            
                }catch(Exception err) { 
                
                 }
                }
                

                     private void primerRegistro(){    
                        try{            
      
                        rs.first();               
                         this.jTF_rfc.setText(rs.getString("RFC"));                         
                         this.jTF_nombre_empleado.setText(rs.getString("Nombre"));             
                         this.jTF_apellido_empleado.setText(rs.getString("Ap_Paterno"));
                         this.jTF_telefono_empleado.setText(rs.getString("Telefono"));   
                         this.jTF_direccion_empleado.setText(rs.getString("Direccion"));
                         this.jTF_ciudad_empleado.setText(rs.getString("Ciudad")); 
                         this.jTF_fecha.setText(rs.getString("Fe_Ingreso"));
                         }catch(Exception err) { 
                                      
                            }    
                     }
                     private void ultimoRegistro(){    
                        try{            
      
                        rs.last();               
                         this.jTF_rfc.setText(rs.getString("RFC"));                         
                         this.jTF_nombre_empleado.setText(rs.getString("Nombre"));             
                         this.jTF_apellido_empleado.setText(rs.getString("Ap_Paterno"));
                         this.jTF_telefono_empleado.setText(rs.getString("Telefono"));   
                         this.jTF_direccion_empleado.setText(rs.getString("Direccion"));
                         this.jTF_ciudad_empleado.setText(rs.getString("Ciudad")); 
                         this.jTF_fecha.setText(rs.getString("Fe_Ingreso"));  
           
                     }catch(Exception err) { 
              
                     }    
                    }
                    
                    private void registrarRegistro() {        
                     try{ 
                           
                       String rfc=this.jTF_rfc.getText(); 
                       String nombre_empleado=this.jTF_nombre_empleado.getText(); 
                       String apellido_empleado=this.jTF_apellido_empleado.getText();
                       int telefono_empleado=Integer.parseInt(this.jTF_telefono_empleado.getText());
                       String direccion_empleado=this.jTF_direccion_empleado.getText();
                       String ciudad_empleado=this.jTF_ciudad_empleado.getText();
                       String fecha=this.jTF_fecha.getText();
                       
                       String sql="Insert into empleados (RFC, Nombre, Ap_Paterno, Direccion, Ciudad, Telefono, Fe_Ingreso)"+" values ('"+rfc +"','"+nombre_empleado+"','"+apellido_empleado+"','"+direccion_empleado+"','"+ciudad_empleado +"','"+telefono_empleado+"','"+fecha+"');";
                     System.out.println(sql);  
            st.executeUpdate(sql); 
            
         
            this.primerRegistro();

        } catch(SQLException ex) { 
             
        } 

    }
                    
             private void borrarRegistro(){
                 try{ 
                    st.executeUpdate("Delete from empleados where RFC="+this.jTF_rfc.getText());


                  } catch(SQLException err){ 
             
              } 

    }
    
            private void modRegistro(){
                try{ 
                 st.executeUpdate("UPDATE empleados SET Nombre='"+this.jTF_nombre_empleado.getText()+"', Ap_Paterno='"+this.jTF_apellido_empleado.getText()+"', Direccion='"+this.jTF_direccion_empleado.getText()+"', Ciudad='"+this.jTF_ciudad_empleado.getText()+"', Telefono='"+this.jTF_telefono_empleado.getText()+"', Fe_Ingreso='"+this.jTF_fecha.getText()+"' WHERE RFC='"+this.jTF_rfc.getText()+"'");

           this.primerRegistro();

       } catch(SQLException err){ 
             
        } 

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jL_titulo_empleado = new javax.swing.JLabel();
        jL_rfc = new javax.swing.JLabel();
        jTF_rfc = new javax.swing.JTextField();
        jL_nombre_empleado = new javax.swing.JLabel();
        jTF_nombre_empleado = new javax.swing.JTextField();
        jTF_apellido_empleado = new javax.swing.JTextField();
        jL_apellido_empleado = new javax.swing.JLabel();
        jTF_telefono_empleado = new javax.swing.JTextField();
        jL_telefono_empleado = new javax.swing.JLabel();
        jTF_direccion_empleado = new javax.swing.JTextField();
        jL_direccion_empleado = new javax.swing.JLabel();
        jL_ciudad_empleado = new javax.swing.JLabel();
        jTF_ciudad_empleado = new javax.swing.JTextField();
        jB_limpiar = new javax.swing.JButton();
        jB_registrar = new javax.swing.JButton();
        jB_borrar = new javax.swing.JButton();
        jB_modificar = new javax.swing.JButton();
        jL_fecha = new javax.swing.JLabel();
        jTF_fecha = new javax.swing.JTextField();
        jB_primero = new javax.swing.JButton();
        jB_anterior = new javax.swing.JButton();
        jB_siguiente = new javax.swing.JButton();
        jB_ultimo = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jB_administrador = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(204, 0, 204));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 204)));
        jPanel1.setForeground(new java.awt.Color(102, 204, 255));

        jL_titulo_empleado.setBackground(new java.awt.Color(51, 204, 0));
        jL_titulo_empleado.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jL_titulo_empleado.setForeground(new java.awt.Color(255, 102, 0));
        jL_titulo_empleado.setText("Registro de Empleados");

        jL_rfc.setBackground(new java.awt.Color(255, 255, 255));
        jL_rfc.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_rfc.setForeground(new java.awt.Color(255, 255, 255));
        jL_rfc.setText("RFC");

        jTF_rfc.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_rfc.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_rfc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_rfcActionPerformed(evt);
            }
        });

        jL_nombre_empleado.setBackground(new java.awt.Color(255, 255, 255));
        jL_nombre_empleado.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_nombre_empleado.setForeground(new java.awt.Color(255, 255, 255));
        jL_nombre_empleado.setText("Nombre(s)");

        jTF_nombre_empleado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_nombre_empleado.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jTF_apellido_empleado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_apellido_empleado.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_apellido_empleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_apellido_empleadoActionPerformed(evt);
            }
        });

        jL_apellido_empleado.setBackground(new java.awt.Color(255, 255, 255));
        jL_apellido_empleado.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_apellido_empleado.setForeground(new java.awt.Color(255, 255, 255));
        jL_apellido_empleado.setText("Apellidos");

        jTF_telefono_empleado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_telefono_empleado.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jL_telefono_empleado.setBackground(new java.awt.Color(255, 255, 255));
        jL_telefono_empleado.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_telefono_empleado.setForeground(new java.awt.Color(255, 255, 255));
        jL_telefono_empleado.setText("Teléfono");

        jTF_direccion_empleado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_direccion_empleado.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jL_direccion_empleado.setBackground(new java.awt.Color(255, 255, 255));
        jL_direccion_empleado.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_direccion_empleado.setForeground(new java.awt.Color(255, 255, 255));
        jL_direccion_empleado.setText("Dirección");

        jL_ciudad_empleado.setBackground(new java.awt.Color(255, 255, 255));
        jL_ciudad_empleado.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_ciudad_empleado.setForeground(new java.awt.Color(255, 255, 255));
        jL_ciudad_empleado.setText("Ciudad");

        jTF_ciudad_empleado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_ciudad_empleado.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_ciudad_empleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_ciudad_empleadoActionPerformed(evt);
            }
        });

        jB_limpiar.setBackground(new java.awt.Color(0, 0, 51));
        jB_limpiar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_limpiar.setForeground(new java.awt.Color(255, 255, 255));
        jB_limpiar.setText("Limpiar");
        jB_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_limpiarActionPerformed(evt);
            }
        });

        jB_registrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_registrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_registrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_registrar.setText("Registrar");
        jB_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_registrarActionPerformed(evt);
            }
        });

        jB_borrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_borrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_borrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_borrar.setText("Borrar");
        jB_borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_borrarActionPerformed(evt);
            }
        });

        jB_modificar.setBackground(new java.awt.Color(0, 0, 51));
        jB_modificar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_modificar.setForeground(new java.awt.Color(255, 255, 255));
        jB_modificar.setText("Modificar");
        jB_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_modificarActionPerformed(evt);
            }
        });

        jL_fecha.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_fecha.setForeground(new java.awt.Color(255, 255, 255));
        jL_fecha.setText("Fecha Ingreso");

        jTF_fecha.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_fecha.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_primero.setBackground(new java.awt.Color(0, 0, 51));
        jB_primero.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_primero.setForeground(new java.awt.Color(255, 255, 255));
        jB_primero.setText("|<");
        jB_primero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_primeroActionPerformed(evt);
            }
        });

        jB_anterior.setBackground(new java.awt.Color(0, 0, 51));
        jB_anterior.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_anterior.setForeground(new java.awt.Color(255, 255, 255));
        jB_anterior.setText("<<");
        jB_anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_anteriorActionPerformed(evt);
            }
        });

        jB_siguiente.setBackground(new java.awt.Color(0, 0, 51));
        jB_siguiente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_siguiente.setForeground(new java.awt.Color(255, 255, 255));
        jB_siguiente.setText(">>");
        jB_siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_siguienteActionPerformed(evt);
            }
        });

        jB_ultimo.setBackground(new java.awt.Color(0, 0, 51));
        jB_ultimo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_ultimo.setForeground(new java.awt.Color(255, 255, 255));
        jB_ultimo.setText(">|");
        jB_ultimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_ultimoActionPerformed(evt);
            }
        });

        jSeparator3.setBackground(new java.awt.Color(0, 51, 255));
        jSeparator3.setForeground(new java.awt.Color(51, 153, 255));
        jSeparator3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 51), new java.awt.Color(0, 51, 255), new java.awt.Color(0, 0, 153)));

        jB_administrador.setBackground(new java.awt.Color(0, 0, 51));
        jB_administrador.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_administrador.setForeground(new java.awt.Color(255, 255, 255));
        jB_administrador.setText("Menú");
        jB_administrador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_administradorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(jL_rfc, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_nombre_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF_rfc, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTF_nombre_empleado, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_telefono_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTF_telefono_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_apellido_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTF_apellido_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_direccion_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTF_direccion_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_ciudad_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jTF_ciudad_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(47, 47, 47))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jL_titulo_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62))
            .addComponent(jSeparator3)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTF_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jB_siguiente)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jB_primero)
                        .addGap(18, 18, 18)
                        .addComponent(jB_anterior)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jB_ultimo)
                .addGap(28, 28, 28))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jB_limpiar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jB_modificar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jB_borrar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jB_administrador)
                    .addComponent(jB_registrar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jL_titulo_empleado)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_rfc)
                    .addComponent(jTF_rfc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_nombre_empleado)
                    .addComponent(jTF_nombre_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF_apellido_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_apellido_empleado))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF_telefono_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_telefono_empleado))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jL_direccion_empleado)
                    .addComponent(jTF_direccion_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTF_ciudad_empleado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_ciudad_empleado))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_fecha)
                    .addComponent(jTF_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_primero)
                    .addComponent(jB_anterior)
                    .addComponent(jB_siguiente)
                    .addComponent(jB_ultimo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_limpiar)
                    .addComponent(jB_modificar)
                    .addComponent(jB_borrar)
                    .addComponent(jB_registrar))
                .addGap(18, 18, 18)
                .addComponent(jB_administrador)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTF_ciudad_empleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_ciudad_empleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_ciudad_empleadoActionPerformed

    private void jTF_rfcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_rfcActionPerformed
           // TODO add your handling code here:
    }//GEN-LAST:event_jTF_rfcActionPerformed

    private void jB_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_limpiarActionPerformed
            this.jTF_apellido_empleado.setText("");                     
            this.jTF_ciudad_empleado.setText("");             
            this.jTF_direccion_empleado.setText("");
            this.jTF_nombre_empleado.setText("");  
            this.jTF_rfc.setText("");
            this.jTF_telefono_empleado.setText("");
            this.jTF_fecha.setText("");
    }
            
    
            public void limpiarCajasTexto(){
                this.jTF_apellido_empleado.setText("");
                this.jTF_ciudad_empleado.setText("");             
                this.jTF_direccion_empleado.setText("");
                this.jTF_nombre_empleado.setText("");  
                this.jTF_rfc.setText("");
                this.jTF_telefono_empleado.setText("");
                this.jTF_fecha.setText("");

    


        // TODO add your handling code here:
    }//GEN-LAST:event_jB_limpiarActionPerformed

    private void jTF_apellido_empleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_apellido_empleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_apellido_empleadoActionPerformed

    private void jB_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_registrarActionPerformed
        registrarRegistro();
        
        JOptionPane.showMessageDialog(this, "Registro Guardado");
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_registrarActionPerformed

    private void jB_borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_borrarActionPerformed
        borrarRegistro();        // TODO add your handling code here:
    JOptionPane.showMessageDialog(this, "¿Desea borrar el Registro?");
    JOptionPane.showMessageDialog(this, "¡Registro borrado!");


        // TODO add your handling code here:
    }//GEN-LAST:event_jB_borrarActionPerformed

    private void jB_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_modificarActionPerformed
               modRegistro();
               JOptionPane.showMessageDialog(this, "Registro Modificado");
               
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_modificarActionPerformed

    private void jB_primeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_primeroActionPerformed
        primerRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_primeroActionPerformed

    private void jB_anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_anteriorActionPerformed
            anteriorRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_anteriorActionPerformed

    private void jB_siguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_siguienteActionPerformed
        siguienteRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_siguienteActionPerformed

    private void jB_ultimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ultimoActionPerformed
        ultimoRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_ultimoActionPerformed

    private void jB_administradorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_administradorActionPerformed
        Administrador menu = new Administrador();
        menu.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_administradorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(empleados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new empleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jB_administrador;
    private javax.swing.JButton jB_anterior;
    private javax.swing.JButton jB_borrar;
    private javax.swing.JButton jB_limpiar;
    private javax.swing.JButton jB_modificar;
    private javax.swing.JButton jB_primero;
    private javax.swing.JButton jB_registrar;
    private javax.swing.JButton jB_siguiente;
    private javax.swing.JButton jB_ultimo;
    private javax.swing.JLabel jL_apellido_empleado;
    private javax.swing.JLabel jL_ciudad_empleado;
    private javax.swing.JLabel jL_direccion_empleado;
    private javax.swing.JLabel jL_fecha;
    private javax.swing.JLabel jL_nombre_empleado;
    private javax.swing.JLabel jL_rfc;
    private javax.swing.JLabel jL_telefono_empleado;
    private javax.swing.JLabel jL_titulo_empleado;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTF_apellido_empleado;
    private javax.swing.JTextField jTF_ciudad_empleado;
    private javax.swing.JTextField jTF_direccion_empleado;
    private javax.swing.JTextField jTF_fecha;
    private javax.swing.JTextField jTF_nombre_empleado;
    private javax.swing.JTextField jTF_rfc;
    private javax.swing.JTextField jTF_telefono_empleado;
    // End of variables declaration//GEN-END:variables
}
