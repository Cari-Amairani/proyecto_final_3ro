package ventanas;


import javax.swing.JOptionPane;


import java.sql.*;
public class serviciosrefaccion extends javax.swing.JFrame {
    

private Connection conexion;     
private Statement st;     
private ResultSet rs;

public serviciosrefaccion() {
        initComponents();
        Conectar();
    }
   


                    public void Conectar(){
                        try{ 
                        conexion=DriverManager.getConnection("jdbc:mysql://localhost:3307/protaller","root","");                     
                        st=conexion.createStatement(); 

                        rs=st.executeQuery("Select * from autos");             

                        rs.first();
                        
                        this.jTF_curp.setText(rs.getString("Curp"));
                        this.jTF_nombre_cliente.setText(rs.getString("Nom_Dueno"));
                        this.jTF_matricula.setText(rs.getString("Matricula"));
                        this.jTF_marca.setText(rs.getString("Marca"));
                        this.jTF_anio.setText(rs.getString("Anio"));
                        this.jTF_color.setText(rs.getString("Color"));
                        this.jTF_numero_serie.setText(rs.getString("No_Serie"));
                        this.jTF_numero_motor.setText(rs.getString("No_Motor"));
                        this.jTF_observaciones.setText(rs.getString("Observaciones"));
                        this.jTF_refaccion.setText(rs.getString("Id_Refacciones"));
                        
                    }catch(SQLException err){ 
                        
                    } 

                }
                    private void siguienteRegistro(){    
                    try{            
                    if(rs.isLast()==false) {   
                     rs.next();               
                        this.jTF_curp.setText(rs.getString("Curp"));
                        this.jTF_nombre_cliente.setText(rs.getString("Nom_Dueno"));
                        this.jTF_matricula.setText(rs.getString("Matricula"));
                        this.jTF_marca.setText(rs.getString("Marca"));
                        this.jTF_anio.setText(rs.getString("Anio"));
                        this.jTF_color.setText(rs.getString("Color"));
                        this.jTF_numero_serie.setText(rs.getString("No_Serie"));
                        this.jTF_numero_motor.setText(rs.getString("No_Motor"));
                        this.jTF_observaciones.setText(rs.getString("Observaciones"));
                        this.jTF_refaccion.setText(rs.getString("Id_Refacciones"));
             }        
            }catch(Exception err) {   
             }    
            }
                    private void anteriorRegistro(){    
                        try{            
     
                        rs.previous();               
                        this.jTF_curp.setText(rs.getString("Curp"));
                        this.jTF_nombre_cliente.setText(rs.getString("Nom_Dueno"));
                        this.jTF_matricula.setText(rs.getString("Matricula"));
                        this.jTF_marca.setText(rs.getString("Marca"));
                        this.jTF_anio.setText(rs.getString("Anio"));
                        this.jTF_color.setText(rs.getString("Color"));
                        this.jTF_numero_serie.setText(rs.getString("No_Serie"));
                        this.jTF_numero_motor.setText(rs.getString("No_Motor"));
                        this.jTF_observaciones.setText(rs.getString("Observaciones"));
                        this.jTF_refaccion.setText(rs.getString("Id_Refacciones"));
            
                }catch(Exception err) { 
                
                 }
                }
                    private void primerRegistro(){    
                        try{            
      
                        rs.first();               
                        this.jTF_curp.setText(rs.getString("Curp"));
                        this.jTF_nombre_cliente.setText(rs.getString("Nom_Dueno"));
                        this.jTF_matricula.setText(rs.getString("Matricula"));
                        this.jTF_marca.setText(rs.getString("Marca"));
                        this.jTF_anio.setText(rs.getString("Anio"));
                        this.jTF_color.setText(rs.getString("Color"));
                        this.jTF_numero_serie.setText(rs.getString("No_Serie"));
                        this.jTF_numero_motor.setText(rs.getString("No_Motor"));
                        this.jTF_observaciones.setText(rs.getString("Observaciones"));
                        this.jTF_refaccion.setText(rs.getString("Id_Refacciones"));
                        
                }catch(Exception err) { 
                                      
                            }    
                     }
                    private void ultimoRegistro(){    
                        try{            
      
                        rs.last();               
                         this.jTF_curp.setText(rs.getString("Curp"));
                        this.jTF_nombre_cliente.setText(rs.getString("Nom_Dueno"));
                        this.jTF_matricula.setText(rs.getString("Matricula"));
                        this.jTF_marca.setText(rs.getString("Marca"));
                        this.jTF_anio.setText(rs.getString("Anio"));
                        this.jTF_color.setText(rs.getString("Color"));
                        this.jTF_numero_serie.setText(rs.getString("No_Serie"));
                        this.jTF_numero_motor.setText(rs.getString("No_Motor"));
                        this.jTF_observaciones.setText(rs.getString("Observaciones"));
                        this.jTF_refaccion.setText(rs.getString("Id_Refacciones")); 
           
                     }catch(Exception err) { 
              
                     }    
                    }
                    
                         private void registrarRegistro() {        
                            try{ 
                                String curp= this.jTF_curp.getText();
                                String nombre_cliente= this.jTF_nombre_cliente.getText();
                                int matricula =Integer.parseInt(this.jTF_matricula.getText());
                                String marca =this.jTF_marca.getText();
                                int anio =Integer.parseInt(this.jTF_anio.getText());
                                String color =this.jTF_color.getText();
                                String numero_serie =this.jTF_numero_serie.getText();
                                String numero_motor =this.jTF_numero_motor.getText();
                                String observaciones =this.jTF_observaciones.getText();
                                String refaccion =this.jTF_refaccion.getText();
                        
                       String sql="Insert into autos (Curp, Nom_Dueno, Matricula, Marca, Anio, Color, No_Serie, No_Motor, Observaciones, Id_Refacciones)"+" values ('"+curp +"','"+nombre_cliente+"','"+matricula+"','"+marca+"','"+anio+"','"+color+"','"+numero_serie+"','"+numero_motor+"','"+observaciones+"','"+refaccion+"');";
            System.out.println(sql);
           st.executeUpdate(sql); 
            
            this.primerRegistro();

        } catch(SQLException err) { 
             
        } 

    }
               

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jL_titulo_servicio = new javax.swing.JLabel();
        jL_curp = new javax.swing.JLabel();
        jL_nombre_cliente = new javax.swing.JLabel();
        jTF_curp = new javax.swing.JTextField();
        jTF_nombre_cliente = new javax.swing.JTextField();
        jL_matricula = new javax.swing.JLabel();
        jL_marca = new javax.swing.JLabel();
        jL_anio = new javax.swing.JLabel();
        jL_color = new javax.swing.JLabel();
        jL_numero_serie = new javax.swing.JLabel();
        jL_numero_motor = new javax.swing.JLabel();
        jL_observaciones = new javax.swing.JLabel();
        jTF_matricula = new javax.swing.JTextField();
        jTF_marca = new javax.swing.JTextField();
        jTF_anio = new javax.swing.JTextField();
        jTF_color = new javax.swing.JTextField();
        jTF_numero_serie = new javax.swing.JTextField();
        jTF_numero_motor = new javax.swing.JTextField();
        jTF_observaciones = new javax.swing.JTextField();
        jB_limpiar = new javax.swing.JButton();
        jB_registrar = new javax.swing.JButton();
        jL_refaccion = new javax.swing.JLabel();
        jTF_refaccion = new javax.swing.JTextField();
        jB_primer = new javax.swing.JButton();
        jB_anterior = new javax.swing.JButton();
        jB_siguiente = new javax.swing.JButton();
        jB_ultimo = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jB_administrador = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 204)));
        jPanel1.setForeground(new java.awt.Color(102, 204, 255));

        jL_titulo_servicio.setBackground(new java.awt.Color(51, 255, 0));
        jL_titulo_servicio.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jL_titulo_servicio.setForeground(new java.awt.Color(255, 102, 0));
        jL_titulo_servicio.setText("Registro de Autos");

        jL_curp.setBackground(new java.awt.Color(255, 255, 255));
        jL_curp.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_curp.setForeground(new java.awt.Color(255, 255, 255));
        jL_curp.setText("Curp");

        jL_nombre_cliente.setBackground(new java.awt.Color(255, 255, 255));
        jL_nombre_cliente.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_nombre_cliente.setForeground(new java.awt.Color(255, 255, 255));
        jL_nombre_cliente.setText("Nombre(s) del Cliente");

        jTF_curp.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_curp.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_curp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_curpActionPerformed(evt);
            }
        });

        jTF_nombre_cliente.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_nombre_cliente.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jL_matricula.setBackground(new java.awt.Color(255, 255, 255));
        jL_matricula.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_matricula.setForeground(new java.awt.Color(255, 255, 255));
        jL_matricula.setText("Matricula");

        jL_marca.setBackground(new java.awt.Color(255, 255, 255));
        jL_marca.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_marca.setForeground(new java.awt.Color(255, 255, 255));
        jL_marca.setText("Marca");

        jL_anio.setBackground(new java.awt.Color(255, 255, 255));
        jL_anio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_anio.setForeground(new java.awt.Color(255, 255, 255));
        jL_anio.setText("Año");

        jL_color.setBackground(new java.awt.Color(255, 255, 255));
        jL_color.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_color.setForeground(new java.awt.Color(255, 255, 255));
        jL_color.setText("Color");

        jL_numero_serie.setBackground(new java.awt.Color(255, 255, 255));
        jL_numero_serie.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_numero_serie.setForeground(new java.awt.Color(255, 255, 255));
        jL_numero_serie.setText("No. Serie");

        jL_numero_motor.setBackground(new java.awt.Color(255, 255, 255));
        jL_numero_motor.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_numero_motor.setForeground(new java.awt.Color(255, 255, 255));
        jL_numero_motor.setText("No. Motor");

        jL_observaciones.setBackground(new java.awt.Color(255, 255, 255));
        jL_observaciones.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_observaciones.setForeground(new java.awt.Color(255, 255, 255));
        jL_observaciones.setText("Observaciones");

        jTF_matricula.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_matricula.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jTF_marca.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_marca.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_marca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_marcaActionPerformed(evt);
            }
        });

        jTF_anio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_anio.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jTF_color.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_color.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jTF_numero_serie.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_numero_serie.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jTF_numero_motor.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_numero_motor.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jTF_observaciones.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_observaciones.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_observaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_observacionesActionPerformed(evt);
            }
        });

        jB_limpiar.setBackground(new java.awt.Color(0, 0, 51));
        jB_limpiar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_limpiar.setForeground(new java.awt.Color(255, 255, 255));
        jB_limpiar.setText("Limpiar");
        jB_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_limpiarActionPerformed(evt);
            }
        });

        jB_registrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_registrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_registrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_registrar.setText("Registrar");
        jB_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_registrarActionPerformed(evt);
            }
        });

        jL_refaccion.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_refaccion.setForeground(new java.awt.Color(255, 255, 255));
        jL_refaccion.setText("Id_Refacciones");

        jTF_refaccion.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_refaccion.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_primer.setBackground(new java.awt.Color(0, 0, 51));
        jB_primer.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_primer.setForeground(new java.awt.Color(255, 255, 255));
        jB_primer.setText("|<");
        jB_primer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_primerActionPerformed(evt);
            }
        });

        jB_anterior.setBackground(new java.awt.Color(0, 0, 51));
        jB_anterior.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_anterior.setForeground(new java.awt.Color(255, 255, 255));
        jB_anterior.setText("<<");
        jB_anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_anteriorActionPerformed(evt);
            }
        });

        jB_siguiente.setBackground(new java.awt.Color(0, 0, 51));
        jB_siguiente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_siguiente.setForeground(new java.awt.Color(255, 255, 255));
        jB_siguiente.setText(">>");
        jB_siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_siguienteActionPerformed(evt);
            }
        });

        jB_ultimo.setBackground(new java.awt.Color(0, 0, 51));
        jB_ultimo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_ultimo.setForeground(new java.awt.Color(255, 255, 255));
        jB_ultimo.setText(">|");
        jB_ultimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_ultimoActionPerformed(evt);
            }
        });

        jSeparator2.setBackground(new java.awt.Color(0, 51, 255));
        jSeparator2.setForeground(new java.awt.Color(51, 153, 255));
        jSeparator2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 51), new java.awt.Color(0, 51, 255), new java.awt.Color(0, 0, 153)));

        jSeparator3.setBackground(new java.awt.Color(0, 51, 255));
        jSeparator3.setForeground(new java.awt.Color(51, 153, 255));
        jSeparator3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 51), new java.awt.Color(0, 51, 255), new java.awt.Color(0, 0, 153)));

        jB_administrador.setBackground(new java.awt.Color(0, 0, 51));
        jB_administrador.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_administrador.setForeground(new java.awt.Color(255, 255, 255));
        jB_administrador.setText("Menú");
        jB_administrador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_administradorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jB_limpiar)
                .addGap(18, 18, 18)
                .addComponent(jB_primer)
                .addGap(18, 18, 18)
                .addComponent(jB_anterior)
                .addGap(18, 18, 18)
                .addComponent(jB_siguiente)
                .addGap(18, 18, 18)
                .addComponent(jB_ultimo)
                .addGap(18, 18, 18)
                .addComponent(jB_registrar)
                .addGap(83, 83, 83))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_curp, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTF_curp, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jL_nombre_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTF_nombre_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(179, 179, 179)
                                .addComponent(jL_titulo_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jL_numero_serie, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jL_matricula, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTF_matricula, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                                    .addComponent(jTF_numero_serie))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jL_marca, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTF_marca, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jL_anio, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTF_anio, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jL_color, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTF_color, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jL_numero_motor, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTF_numero_motor, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jL_refaccion)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTF_refaccion, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jTF_observaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 477, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jSeparator3)
            .addComponent(jSeparator2)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jL_observaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(255, 255, 255))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jB_administrador)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jL_titulo_servicio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_curp)
                    .addComponent(jTF_curp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_nombre_cliente)
                    .addComponent(jTF_nombre_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_matricula)
                    .addComponent(jTF_matricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_marca)
                    .addComponent(jTF_marca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_anio)
                    .addComponent(jTF_anio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_color)
                    .addComponent(jTF_color, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_numero_serie)
                    .addComponent(jTF_numero_serie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_numero_motor)
                    .addComponent(jTF_numero_motor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_refaccion)
                    .addComponent(jTF_refaccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jL_observaciones)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTF_observaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_registrar)
                    .addComponent(jB_ultimo)
                    .addComponent(jB_siguiente)
                    .addComponent(jB_anterior)
                    .addComponent(jB_primer)
                    .addComponent(jB_limpiar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jB_administrador)
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTF_observacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_observacionesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_observacionesActionPerformed

    private void jTF_curpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_curpActionPerformed
            


        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_curpActionPerformed

    private void jTF_marcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_marcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_marcaActionPerformed

    private void jB_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_limpiarActionPerformed
            this.jTF_curp.setText("");                     
            this.jTF_nombre_cliente.setText("");             
            this.jTF_matricula.setText("");
            this.jTF_marca.setText("");  
            this.jTF_anio.setText("");
            this.jTF_color.setText("");  
            this.jTF_numero_serie.setText("");
            this.jTF_numero_motor.setText("");  
            this.jTF_observaciones.setText("");
    }
            public void limpiarCajasTexto(){
            this.jTF_curp.setText("");                     
            this.jTF_nombre_cliente.setText("");             
            this.jTF_matricula.setText("");
            this.jTF_marca.setText("");  
            this.jTF_anio.setText("");
            this.jTF_color.setText("");  
            this.jTF_numero_serie.setText("");
            this.jTF_numero_motor.setText("");  
            this.jTF_observaciones.setText("");
            // TODO add your handling code here:
    }//GEN-LAST:event_jB_limpiarActionPerformed

    private void jB_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_registrarActionPerformed
        registrarRegistro();       
            JOptionPane.showMessageDialog(this, "Registro Guardado");
// TODO add your handling code here:
    }//GEN-LAST:event_jB_registrarActionPerformed

    private void jB_ultimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ultimoActionPerformed
        ultimoRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_ultimoActionPerformed

    private void jB_siguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_siguienteActionPerformed
            siguienteRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_siguienteActionPerformed

    private void jB_anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_anteriorActionPerformed
            anteriorRegistro();
            // TODO add your handling code here:
    }//GEN-LAST:event_jB_anteriorActionPerformed

    private void jB_primerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_primerActionPerformed
            primerRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_primerActionPerformed

    private void jB_administradorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_administradorActionPerformed
        Administrador menu = new Administrador();
        menu.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_administradorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(serviciosrefaccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(serviciosrefaccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(serviciosrefaccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(serviciosrefaccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new serviciosrefaccion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jB_administrador;
    private javax.swing.JButton jB_anterior;
    private javax.swing.JButton jB_limpiar;
    private javax.swing.JButton jB_primer;
    private javax.swing.JButton jB_registrar;
    private javax.swing.JButton jB_siguiente;
    private javax.swing.JButton jB_ultimo;
    private javax.swing.JLabel jL_anio;
    private javax.swing.JLabel jL_color;
    private javax.swing.JLabel jL_curp;
    private javax.swing.JLabel jL_marca;
    private javax.swing.JLabel jL_matricula;
    private javax.swing.JLabel jL_nombre_cliente;
    private javax.swing.JLabel jL_numero_motor;
    private javax.swing.JLabel jL_numero_serie;
    private javax.swing.JLabel jL_observaciones;
    private javax.swing.JLabel jL_refaccion;
    private javax.swing.JLabel jL_titulo_servicio;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTF_anio;
    private javax.swing.JTextField jTF_color;
    private javax.swing.JTextField jTF_curp;
    private javax.swing.JTextField jTF_marca;
    private javax.swing.JTextField jTF_matricula;
    private javax.swing.JTextField jTF_nombre_cliente;
    private javax.swing.JTextField jTF_numero_motor;
    private javax.swing.JTextField jTF_numero_serie;
    private javax.swing.JTextField jTF_observaciones;
    private javax.swing.JTextField jTF_refaccion;
    // End of variables declaration//GEN-END:variables
}
