package ventanas;


import javax.swing.JOptionPane;


import java.sql.*;
public class clientes extends javax.swing.JFrame {
    

 private Connection conexion;     
private Statement st;     
private ResultSet rs; 

public clientes() {
        initComponents();
        Conectar();
    }
    


                    public void Conectar(){

                     try{ 
                        conexion=DriverManager.getConnection("jdbc:mysql://localhost:3307/protaller","root","");                     
                        st=conexion.createStatement(); 

                        rs=st.executeQuery("Select * from clientes");             

                        rs.first(); 

            this.jTF_nombres.setText(rs.getString("Nombre"));                         
            this.jTF_apellidos.setText(rs.getString("Ap_Paterno"));             
            this.jTF_telefono.setText(rs.getString("Telefono"));
            this.jTF_direccion.setText(rs.getString("Direccion")); 
            this.jTF_ciudad.setText(rs.getString("Ciudad"));
            this.jTF_servicio.setText(rs.getString("No_Servicio"));
             
                    }catch(SQLException err){ 
                         
                    } 

                }
                    private void siguienteRegistro(){    
                    try{            
                    if(rs.isLast()==false) {   
                 rs.next();               
                     this.jTF_nombres.setText(rs.getString("Nombre"));                         
                     this.jTF_apellidos.setText(rs.getString("Ap_Paterno"));             
                     this.jTF_telefono.setText(rs.getString("Telefono"));
                     this.jTF_direccion.setText(rs.getString("Direccion")); 
                     this.jTF_ciudad.setText(rs.getString("Ciudad"));
                     this.jTF_servicio.setText(rs.getString("No_Servicio")); 
             }        
            }catch(Exception err) {   
             }    
            }
                private void anteriorRegistro(){    
                        try{            
     
                        rs.previous();               
                         this.jTF_nombres.setText(rs.getString("Nombre"));                         
                         this.jTF_apellidos.setText(rs.getString("Ap_Paterno"));             
                         this.jTF_telefono.setText(rs.getString("Telefono"));
                         this.jTF_direccion.setText(rs.getString("Direccion"));   
                         this.jTF_ciudad.setText(rs.getString("Ciudad"));
                         this.jTF_servicio.setText(rs.getString("No_Servicio"));
            
                }catch(Exception err) { 
                
                 }    
    }
                    
                    private void primerRegistro(){    
                        try{            
      
                        rs.first();               
                         this.jTF_nombres.setText(rs.getString("Nombre"));                         
                         this.jTF_apellidos.setText(rs.getString("Ap_Paterno"));             
                         this.jTF_telefono.setText(rs.getString("Telefono"));
                         this.jTF_direccion.setText(rs.getString("Direccion"));   
                         this.jTF_ciudad.setText(rs.getString("Ciudad"));
                         this.jTF_servicio.setText(rs.getString("No_Servicio"));
                         
                        
                         }catch(Exception err) { 
                                      
                            }    
                     }
                    
                    private void ultimoRegistro(){    
                        try{            
      
                        rs.last();               
                         this.jTF_nombres.setText(rs.getString("Nombre"));                         
                         this.jTF_apellidos.setText(rs.getString("Ap_Paterno"));             
                         this.jTF_telefono.setText(rs.getString("Telefono"));
                         this.jTF_direccion.setText(rs.getString("Direccion"));   
                         this.jTF_ciudad.setText(rs.getString("Ciudad"));
                         this.jTF_servicio.setText(rs.getString("No_Servicio"));  
           
                     }catch(Exception err) { 
              
                     }    
                    }
                    private void registrarRegistro() {        
                     try{ 
                           
                       String Nombre=this.jTF_nombres.getText(); 
                       String apellidos=this.jTF_apellidos.getText(); 
                       String telefono=this.jTF_telefono.getText();
                       String direccion=this.jTF_direccion.getText();
                       String ciudad=this.jTF_ciudad.getText();
                       int servicio=Integer.parseInt(this.jTF_servicio.getText());
                       
                     String sql="Insert into clientes (Nombre, Ap_Paterno, Telefono, Direccion, Ciudad, No_Servicio)"+" values ('"+Nombre +"','"+apellidos+"','"+telefono+"','"+direccion+"','"+ciudad +"', '"+servicio+"');";
                   System.out.println(sql);
            st.executeUpdate(sql); 
            
         
            this.primerRegistro();

        } catch(SQLException err) { 
             
        } 

    }
                    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jL_titulo_cliente = new javax.swing.JLabel();
        jL_nombres = new javax.swing.JLabel();
        jTF_nombres = new javax.swing.JTextField();
        jL_apellidos = new javax.swing.JLabel();
        jTF_apellidos = new javax.swing.JTextField();
        jL_telefono = new javax.swing.JLabel();
        jTF_telefono = new javax.swing.JTextField();
        jL_direccion = new javax.swing.JLabel();
        jTF_direccion = new javax.swing.JTextField();
        jL_ciudad = new javax.swing.JLabel();
        jTF_ciudad = new javax.swing.JTextField();
        jB_limpiar = new javax.swing.JButton();
        jB_registrar = new javax.swing.JButton();
        jL_servicio = new javax.swing.JLabel();
        jTF_servicio = new javax.swing.JTextField();
        jB_primero = new javax.swing.JButton();
        jB_anterior = new javax.swing.JButton();
        jB_siguiente = new javax.swing.JButton();
        jB_ultimo = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jB_administrador = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 204)));
        jPanel1.setForeground(new java.awt.Color(102, 204, 255));

        jL_titulo_cliente.setBackground(new java.awt.Color(51, 204, 0));
        jL_titulo_cliente.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jL_titulo_cliente.setForeground(new java.awt.Color(255, 102, 0));
        jL_titulo_cliente.setText("Registro de Clientes");

        jL_nombres.setBackground(new java.awt.Color(255, 255, 255));
        jL_nombres.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_nombres.setForeground(new java.awt.Color(255, 255, 255));
        jL_nombres.setText("Nombre(s)");

        jTF_nombres.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTF_nombres.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_nombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_nombresActionPerformed(evt);
            }
        });

        jL_apellidos.setBackground(new java.awt.Color(255, 255, 255));
        jL_apellidos.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_apellidos.setForeground(new java.awt.Color(255, 255, 255));
        jL_apellidos.setText("Apellidos");

        jTF_apellidos.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTF_apellidos.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jL_telefono.setBackground(new java.awt.Color(255, 255, 255));
        jL_telefono.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_telefono.setForeground(new java.awt.Color(255, 255, 255));
        jL_telefono.setText("Teléfono");

        jTF_telefono.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTF_telefono.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_telefonoActionPerformed(evt);
            }
        });

        jL_direccion.setBackground(new java.awt.Color(255, 255, 255));
        jL_direccion.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_direccion.setForeground(new java.awt.Color(255, 255, 255));
        jL_direccion.setText("Dirección");

        jTF_direccion.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTF_direccion.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jL_ciudad.setBackground(new java.awt.Color(255, 255, 255));
        jL_ciudad.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_ciudad.setForeground(new java.awt.Color(255, 255, 255));
        jL_ciudad.setText("Ciudad");

        jTF_ciudad.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTF_ciudad.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_limpiar.setBackground(new java.awt.Color(0, 0, 51));
        jB_limpiar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_limpiar.setForeground(new java.awt.Color(255, 255, 255));
        jB_limpiar.setText("Limpiar");
        jB_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_limpiarActionPerformed(evt);
            }
        });

        jB_registrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_registrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_registrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_registrar.setText("Registrar");
        jB_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_registrarActionPerformed(evt);
            }
        });

        jL_servicio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_servicio.setForeground(new java.awt.Color(255, 255, 255));
        jL_servicio.setText("Número de Servicio");

        jTF_servicio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_servicio.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_primero.setBackground(new java.awt.Color(0, 0, 51));
        jB_primero.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_primero.setForeground(new java.awt.Color(255, 255, 255));
        jB_primero.setText("|<");
        jB_primero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_primeroActionPerformed(evt);
            }
        });

        jB_anterior.setBackground(new java.awt.Color(0, 0, 51));
        jB_anterior.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_anterior.setForeground(new java.awt.Color(255, 255, 255));
        jB_anterior.setText("<<");
        jB_anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_anteriorActionPerformed(evt);
            }
        });

        jB_siguiente.setBackground(new java.awt.Color(0, 0, 51));
        jB_siguiente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_siguiente.setForeground(new java.awt.Color(255, 255, 255));
        jB_siguiente.setText(">>");
        jB_siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_siguienteActionPerformed(evt);
            }
        });

        jB_ultimo.setBackground(new java.awt.Color(0, 0, 51));
        jB_ultimo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_ultimo.setForeground(new java.awt.Color(255, 255, 255));
        jB_ultimo.setText(">|");
        jB_ultimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_ultimoActionPerformed(evt);
            }
        });

        jSeparator3.setBackground(new java.awt.Color(0, 51, 255));
        jSeparator3.setForeground(new java.awt.Color(51, 153, 255));
        jSeparator3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 51), new java.awt.Color(0, 51, 255), new java.awt.Color(0, 0, 153)));

        jB_administrador.setBackground(new java.awt.Color(0, 0, 51));
        jB_administrador.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_administrador.setForeground(new java.awt.Color(255, 255, 255));
        jB_administrador.setText("Menú");
        jB_administrador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_administradorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 25, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jL_titulo_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jL_nombres, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jL_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jL_telefono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jL_direccion, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTF_telefono, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE)
                                    .addComponent(jTF_apellidos)
                                    .addComponent(jTF_nombres)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jL_ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTF_ciudad, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE)
                                    .addComponent(jTF_direccion))))))
                .addGap(33, 33, 33))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jL_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77)
                .addComponent(jTF_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jB_limpiar)
                        .addGap(18, 18, 18)
                        .addComponent(jB_registrar)
                        .addGap(18, 18, 18)
                        .addComponent(jB_administrador))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jB_primero)
                        .addGap(18, 18, 18)
                        .addComponent(jB_anterior)
                        .addGap(18, 18, 18)
                        .addComponent(jB_siguiente)
                        .addGap(18, 18, 18)
                        .addComponent(jB_ultimo)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jL_titulo_cliente)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jL_nombres)
                            .addComponent(jTF_nombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jL_apellidos)
                            .addComponent(jTF_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTF_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jL_telefono))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jL_direccion)
                            .addComponent(jTF_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTF_ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jL_ciudad))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jL_servicio)
                            .addComponent(jTF_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 82, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jB_primero)
                            .addComponent(jB_anterior)
                            .addComponent(jB_siguiente)
                            .addComponent(jB_ultimo))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jB_limpiar)
                            .addComponent(jB_registrar)
                            .addComponent(jB_administrador))))
                .addGap(46, 46, 46))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jB_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_limpiarActionPerformed
      
            this.jTF_nombres.setText("");                     
            this.jTF_apellidos.setText("");             
            this.jTF_telefono.setText("");
            this.jTF_direccion.setText("");  
            this.jTF_ciudad.setText("");
            this.jTF_servicio.setText("");
            
    }
            public void limpiarCajasTexto(){
                this.jTF_nombres.setText("");
                this.jTF_apellidos.setText("");
                this.jTF_telefono.setText("");
                this.jTF_direccion.setText("");
                this.jTF_ciudad.setText("");
                this.jTF_servicio.setText("");    
      
                    // TODO add your handling code here:
    }//GEN-LAST:event_jB_limpiarActionPerformed

    private void jTF_telefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_telefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_telefonoActionPerformed

    private void jTF_nombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_nombresActionPerformed
        
                // TODO add your handling code here:
    }//GEN-LAST:event_jTF_nombresActionPerformed

    private void jB_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_registrarActionPerformed
        registrarRegistro();
        JOptionPane.showMessageDialog(this, "Registro Guardado");
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_registrarActionPerformed

    private void jB_primeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_primeroActionPerformed
                primerRegistro();
            
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_primeroActionPerformed

    private void jB_anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_anteriorActionPerformed
            anteriorRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_anteriorActionPerformed

    private void jB_siguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_siguienteActionPerformed
                siguienteRegistro();
            // TODO add your handling code here:
    }//GEN-LAST:event_jB_siguienteActionPerformed

    private void jB_ultimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ultimoActionPerformed
            ultimoRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_ultimoActionPerformed

    private void jB_administradorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_administradorActionPerformed
        Administrador menu = new Administrador();
        menu.setVisible(true);
                // TODO add your handling code here:
    }//GEN-LAST:event_jB_administradorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new clientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jB_administrador;
    private javax.swing.JButton jB_anterior;
    private javax.swing.JButton jB_limpiar;
    private javax.swing.JButton jB_primero;
    private javax.swing.JButton jB_registrar;
    private javax.swing.JButton jB_siguiente;
    private javax.swing.JButton jB_ultimo;
    private javax.swing.JLabel jL_apellidos;
    private javax.swing.JLabel jL_ciudad;
    private javax.swing.JLabel jL_direccion;
    private javax.swing.JLabel jL_nombres;
    private javax.swing.JLabel jL_servicio;
    private javax.swing.JLabel jL_telefono;
    private javax.swing.JLabel jL_titulo_cliente;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTF_apellidos;
    private javax.swing.JTextField jTF_ciudad;
    private javax.swing.JTextField jTF_direccion;
    private javax.swing.JTextField jTF_nombres;
    private javax.swing.JTextField jTF_servicio;
    private javax.swing.JTextField jTF_telefono;
    // End of variables declaration//GEN-END:variables
}
