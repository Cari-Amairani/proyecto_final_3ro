package ventanas;


import javax.swing.JOptionPane;


import java.sql.*;
public class taller extends javax.swing.JFrame {

    
private Connection conexion;     
private Statement st;     
private ResultSet rs;  
    
 public taller() {
        initComponents();
        Conectar();
    }

                 public void Conectar(){
                        try{ 
                        conexion=DriverManager.getConnection("jdbc:mysql://localhost:3307/protaller","root","");                     
                        st=conexion.createStatement(); 

                        rs=st.executeQuery("Select * from refacciones");             

                        rs.first();
                        
                        this.jTF_id.setText(rs.getString("Id_Refacciones"));
                        this.jTF_nombre_refaccion.setText(rs.getString("Nom_Refaccion"));
                        this.jTF_descripcion.setText(rs.getString("Descripcion"));
                        
                        this.jTF_cantidad_Existencia.setText(rs.getString("Cant_Existencia"));
                        this.jTF_modelo_carro.setText(rs.getString("Mod_Carro"));
                        this.jTF_precio_compra.setText(rs.getString("Precio_Compra"));
                        this.jTF_precio_venta.setText(rs.getString("Precio_Venta"));
                        
                    }catch(SQLException err){ 
                        JOptionPane.showMessageDialog(null,"Error "+err.getMessage()); 
                    } 

                }
                 private void siguienteRegistro(){    
                    try{            
                    if(rs.isLast()==false) {   
                     rs.next();               
                       this.jTF_id.setText(rs.getString("Id_Refacciones"));
                        this.jTF_nombre_refaccion.setText(rs.getString("Nom_Refaccion"));
                        this.jTF_descripcion.setText(rs.getString("Descripcion"));
                        
                        this.jTF_cantidad_Existencia.setText(rs.getString("Cant_Existencia"));
                        this.jTF_modelo_carro.setText(rs.getString("Mod_Carro"));
                        this.jTF_precio_compra.setText(rs.getString("Precio_Compra"));
                        this.jTF_precio_venta.setText(rs.getString("Precio_Venta"));
             }        
            }catch(Exception err) {   
             }    
            }
                 private void anteriorRegistro(){    
                        try{            
     
                        rs.previous();               
                        this.jTF_id.setText(rs.getString("Id_Refacciones"));
                        this.jTF_nombre_refaccion.setText(rs.getString("Nom_Refaccion"));
                        this.jTF_descripcion.setText(rs.getString("Descripcion"));
                       
                        this.jTF_cantidad_Existencia.setText(rs.getString("Cant_Existencia"));
                        this.jTF_modelo_carro.setText(rs.getString("Mod_Carro"));
                        this.jTF_precio_compra.setText(rs.getString("Precio_Compra"));
                        this.jTF_precio_venta.setText(rs.getString("Precio_Venta"));
            
    }catch(Exception err) { 
                
    }    
    }
              
                 private void primerRegistro(){    
                        try{            
      
                        rs.first();               
                        this.jTF_id.setText(rs.getString("Id_Refacciones"));
                        this.jTF_nombre_refaccion.setText(rs.getString("Nom_Refaccion"));
                        this.jTF_descripcion.setText(rs.getString("Descripcion"));
                        
                        this.jTF_cantidad_Existencia.setText(rs.getString("Cant_Existencia"));
                        this.jTF_modelo_carro.setText(rs.getString("Mod_Carro"));
                        this.jTF_precio_compra.setText(rs.getString("Precio_Compra"));
                        this.jTF_precio_venta.setText(rs.getString("Precio_Venta"));
                        
                    }catch(Exception err) { 
                                      
                            }    
                     }
                 private void ultimoRegistro(){    
                        try{            
      
                        rs.last();               
                         this.jTF_id.setText(rs.getString("Id_Refacciones"));
                        this.jTF_nombre_refaccion.setText(rs.getString("Nom_Refaccion"));
                        this.jTF_descripcion.setText(rs.getString("Descripcion"));
                       
                        this.jTF_cantidad_Existencia.setText(rs.getString("Cant_Existencia"));
                        this.jTF_modelo_carro.setText(rs.getString("Mod_Carro"));
                        this.jTF_precio_compra.setText(rs.getString("Precio_Compra"));
                        this.jTF_precio_venta.setText(rs.getString("Precio_Venta"));
           
                     }catch(Exception err) { 
              
                     }    
                    }
                 
                 private void registrarRegistro() {        
                            try{ 
                                String id= this.jTF_id.getText();
                                String nombre_refaccion= this.jTF_nombre_refaccion.getText();
                                String descripcion =this.jTF_descripcion.getText();
                                
                                int cantidad_Existencia =Integer.parseInt(this.jTF_cantidad_Existencia.getText());
                                String modelo_carro =this.jTF_modelo_carro.getText();
                                String precio_compra =this.jTF_precio_compra.getText();
                                String precio_venta =this.jTF_precio_venta.getText();
                                
                        String sql="Insert into refacciones (Id_Refacciones, Nom_Refaccion, Descripcion, Cantidad_Ref, Cant_Existencia, Mod_Carro, Precio_Compra, Precio_Venta)"+" values ('"+id+"','"+nombre_refaccion+"','"+descripcion+"','"+cantidad_Existencia+"','"+modelo_carro+"','"+precio_compra+"','"+precio_venta+"');";    
             System.out.println(sql);      
            st.executeUpdate(sql); 
            
            this.primerRegistro();

        } catch(SQLException err) { 
             
        } 

    }
                 private void borrarRegistro(){
                 try{ 
                    st.executeUpdate("Delete from refacciones where Id_Refacciones="+this.jTF_id.getText());


                  } catch(SQLException err){ 
             
              } 

    }
    
            private void modRegistro(){
                try{ 
                 st.executeUpdate("UPDATE refacciones SET Nom_Refaccion='"+this.jTF_nombre_refaccion.getText()+"', Descripcion='"+this.jTF_descripcion.getText()+"', Mod_Carro='"+this.jTF_modelo_carro.getText()+"', Precio_Compra='"+this.jTF_precio_compra.getText()+"', Precio_Venta='"+this.jTF_precio_venta.getText()+"' WHERE Id_Refacciones='"+this.jTF_id.getText()+"'");
                 st.executeUpdate("UPDATE refacciones set Cant_Existencia =  Cant_Existencia + '" + this.jTF_cantidad_Existencia.getText()+"'");
           this.primerRegistro();

       } catch(SQLException err){ 
            
        } 

    }
 
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDesktopPane1 = new javax.swing.JDesktopPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jL_titulo_refaccion = new javax.swing.JLabel();
        jL_id = new javax.swing.JLabel();
        jTF_id = new javax.swing.JTextField();
        jL_nombre_refaccion = new javax.swing.JLabel();
        jTF_nombre_refaccion = new javax.swing.JTextField();
        jL_descripcion = new javax.swing.JLabel();
        jTF_descripcion = new javax.swing.JTextField();
        jL_cantidad_existencia = new javax.swing.JLabel();
        jTF_cantidad_Existencia = new javax.swing.JTextField();
        jL_precio_venta = new javax.swing.JLabel();
        jTF_precio_venta = new javax.swing.JTextField();
        jL_precio_compra = new javax.swing.JLabel();
        jTF_precio_compra = new javax.swing.JTextField();
        jL_modelo_carro = new javax.swing.JLabel();
        jTF_modelo_carro = new javax.swing.JTextField();
        jB_registrar = new javax.swing.JButton();
        jB_limpiar = new javax.swing.JButton();
        jB_borrar = new javax.swing.JButton();
        jB_modificar = new javax.swing.JButton();
        jB_primer = new javax.swing.JButton();
        jB_anterior = new javax.swing.JButton();
        jB_siguiente = new javax.swing.JButton();
        jB_ultimo = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jB_administrador = new javax.swing.JButton();

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(204, 255, 255));

        jPanel2.setBackground(new java.awt.Color(0, 0, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(0, 0, 204)));
        jPanel2.setForeground(new java.awt.Color(102, 204, 255));

        jL_titulo_refaccion.setBackground(new java.awt.Color(0, 255, 0));
        jL_titulo_refaccion.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jL_titulo_refaccion.setForeground(new java.awt.Color(255, 102, 0));
        jL_titulo_refaccion.setText("Registro de Refacciones");

        jL_id.setBackground(new java.awt.Color(255, 255, 255));
        jL_id.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_id.setForeground(new java.awt.Color(255, 255, 255));
        jL_id.setText("ID");

        jTF_id.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_id.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_idActionPerformed(evt);
            }
        });

        jL_nombre_refaccion.setBackground(new java.awt.Color(255, 255, 255));
        jL_nombre_refaccion.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_nombre_refaccion.setForeground(new java.awt.Color(255, 255, 255));
        jL_nombre_refaccion.setText("Nombre de la Refacción");

        jTF_nombre_refaccion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_nombre_refaccion.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jL_descripcion.setBackground(new java.awt.Color(255, 255, 255));
        jL_descripcion.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_descripcion.setForeground(new java.awt.Color(255, 255, 255));
        jL_descripcion.setText("Descripción");

        jTF_descripcion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_descripcion.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_descripcionActionPerformed(evt);
            }
        });

        jL_cantidad_existencia.setBackground(new java.awt.Color(255, 255, 255));
        jL_cantidad_existencia.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_cantidad_existencia.setForeground(new java.awt.Color(255, 255, 255));
        jL_cantidad_existencia.setText("Cantidad en Existencia");

        jTF_cantidad_Existencia.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_cantidad_Existencia.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jL_precio_venta.setBackground(new java.awt.Color(255, 255, 255));
        jL_precio_venta.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_precio_venta.setForeground(new java.awt.Color(255, 255, 255));
        jL_precio_venta.setText("Precio en Venta");

        jTF_precio_venta.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_precio_venta.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_precio_venta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_precio_ventaActionPerformed(evt);
            }
        });

        jL_precio_compra.setBackground(new java.awt.Color(255, 255, 255));
        jL_precio_compra.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_precio_compra.setForeground(new java.awt.Color(255, 255, 255));
        jL_precio_compra.setText("Precio en Compra");

        jTF_precio_compra.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_precio_compra.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_precio_compra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_precio_compraActionPerformed(evt);
            }
        });

        jL_modelo_carro.setBackground(new java.awt.Color(255, 255, 255));
        jL_modelo_carro.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_modelo_carro.setForeground(new java.awt.Color(255, 255, 255));
        jL_modelo_carro.setText("Modelo ");

        jTF_modelo_carro.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTF_modelo_carro.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_registrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_registrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_registrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_registrar.setText("Registrar");
        jB_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_registrarActionPerformed(evt);
            }
        });

        jB_limpiar.setBackground(new java.awt.Color(0, 0, 51));
        jB_limpiar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_limpiar.setForeground(new java.awt.Color(255, 255, 255));
        jB_limpiar.setText("Limpiar");
        jB_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_limpiarActionPerformed(evt);
            }
        });

        jB_borrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_borrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_borrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_borrar.setText("Borrar");
        jB_borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_borrarActionPerformed(evt);
            }
        });

        jB_modificar.setBackground(new java.awt.Color(0, 0, 51));
        jB_modificar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_modificar.setForeground(new java.awt.Color(255, 255, 255));
        jB_modificar.setText("Modificar");
        jB_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_modificarActionPerformed(evt);
            }
        });

        jB_primer.setBackground(new java.awt.Color(0, 0, 51));
        jB_primer.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_primer.setForeground(new java.awt.Color(255, 255, 255));
        jB_primer.setText("|<");
        jB_primer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_primerActionPerformed(evt);
            }
        });

        jB_anterior.setBackground(new java.awt.Color(0, 0, 51));
        jB_anterior.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_anterior.setForeground(new java.awt.Color(255, 255, 255));
        jB_anterior.setText("<<");
        jB_anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_anteriorActionPerformed(evt);
            }
        });

        jB_siguiente.setBackground(new java.awt.Color(0, 0, 51));
        jB_siguiente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_siguiente.setForeground(new java.awt.Color(255, 255, 255));
        jB_siguiente.setText(">>");
        jB_siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_siguienteActionPerformed(evt);
            }
        });

        jB_ultimo.setBackground(new java.awt.Color(0, 0, 51));
        jB_ultimo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_ultimo.setForeground(new java.awt.Color(255, 255, 255));
        jB_ultimo.setText(">|");
        jB_ultimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_ultimoActionPerformed(evt);
            }
        });

        jSeparator2.setBackground(new java.awt.Color(0, 51, 255));
        jSeparator2.setForeground(new java.awt.Color(51, 153, 255));
        jSeparator2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 51), new java.awt.Color(0, 51, 255), new java.awt.Color(0, 0, 153)));

        jB_administrador.setBackground(new java.awt.Color(0, 0, 51));
        jB_administrador.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_administrador.setForeground(new java.awt.Color(255, 255, 255));
        jB_administrador.setText("Menú");
        jB_administrador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_administradorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jL_precio_compra, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTF_precio_compra, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jL_precio_venta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTF_precio_venta, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(86, 86, 86))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(jL_titulo_refaccion, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jL_id, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jL_descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTF_descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jTF_id, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jL_nombre_refaccion, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTF_nombre_refaccion, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jL_cantidad_existencia, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jTF_cantidad_Existencia, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(jL_modelo_carro)
                        .addGap(18, 18, 18)
                        .addComponent(jTF_modelo_carro, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jB_modificar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jB_borrar))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jB_limpiar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jB_primer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jB_anterior)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jB_siguiente)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jB_ultimo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jB_registrar))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jB_administrador)
                        .addGap(40, 40, 40))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jL_titulo_refaccion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_id)
                    .addComponent(jTF_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jL_nombre_refaccion)
                    .addComponent(jTF_nombre_refaccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jL_descripcion))
                            .addComponent(jTF_descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jL_cantidad_existencia)
                            .addComponent(jTF_cantidad_Existencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jL_modelo_carro)
                            .addComponent(jTF_modelo_carro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jL_precio_compra)
                            .addComponent(jTF_precio_compra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jL_precio_venta)
                            .addComponent(jTF_precio_venta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jB_registrar)
                            .addComponent(jB_ultimo)
                            .addComponent(jB_siguiente)
                            .addComponent(jB_anterior)
                            .addComponent(jB_primer)
                            .addComponent(jB_limpiar))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jB_borrar)
                            .addComponent(jB_modificar))
                        .addGap(0, 31, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jB_administrador)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 463, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTF_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_idActionPerformed
       // TODO add your handling code here:
    }//GEN-LAST:event_jTF_idActionPerformed

    private void jTF_descripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_descripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_descripcionActionPerformed

    private void jTF_precio_ventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_precio_ventaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_precio_ventaActionPerformed

    private void jTF_precio_compraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_precio_compraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_precio_compraActionPerformed

    private void jB_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_limpiarActionPerformed
                        
            this.jTF_cantidad_Existencia.setText("");             
            this.jTF_descripcion.setText("");
            this.jTF_id.setText("");  
            this.jTF_modelo_carro.setText("");
            this.jTF_nombre_refaccion.setText("");
            this.jTF_precio_compra.setText("");  
            this.jTF_precio_venta.setText("");
    }
            public void limpiarCajasTexto(){                     
                this.jTF_cantidad_Existencia.setText("");             
                this.jTF_descripcion.setText("");
                this.jTF_id.setText("");  
                this.jTF_modelo_carro.setText("");
                this.jTF_nombre_refaccion.setText("");
                this.jTF_precio_compra.setText("");  
                this.jTF_precio_venta.setText("");        // TODO add your handling code here:
    }//GEN-LAST:event_jB_limpiarActionPerformed

    private void jB_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_modificarActionPerformed
        modRegistro();
        JOptionPane.showMessageDialog(this, "Registro Modificado");

        // TODO add your handling code here:
    }//GEN-LAST:event_jB_modificarActionPerformed

    private void jB_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_registrarActionPerformed
        registrarRegistro();
        JOptionPane.showMessageDialog(this, "Registro Guardado");
        
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_registrarActionPerformed

    private void jB_borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_borrarActionPerformed
         borrarRegistro();
         JOptionPane.showMessageDialog(this, "¿Desea borrar el Registro?");
         JOptionPane.showMessageDialog(this, "¡Registro borrado!");
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_borrarActionPerformed

    private void jB_primerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_primerActionPerformed
            primerRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_primerActionPerformed

    private void jB_anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_anteriorActionPerformed
            anteriorRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_anteriorActionPerformed

    private void jB_siguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_siguienteActionPerformed
            siguienteRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_siguienteActionPerformed

    private void jB_ultimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ultimoActionPerformed
            ultimoRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_ultimoActionPerformed

    private void jB_administradorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_administradorActionPerformed
        Administrador menu = new Administrador();
        menu.setVisible(true);
            // TODO add your handling code here:
    }//GEN-LAST:event_jB_administradorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(taller.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(taller.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(taller.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(taller.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new taller().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jB_administrador;
    private javax.swing.JButton jB_anterior;
    private javax.swing.JButton jB_borrar;
    private javax.swing.JButton jB_limpiar;
    private javax.swing.JButton jB_modificar;
    private javax.swing.JButton jB_primer;
    private javax.swing.JButton jB_registrar;
    private javax.swing.JButton jB_siguiente;
    private javax.swing.JButton jB_ultimo;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JLabel jL_cantidad_existencia;
    private javax.swing.JLabel jL_descripcion;
    private javax.swing.JLabel jL_id;
    private javax.swing.JLabel jL_modelo_carro;
    private javax.swing.JLabel jL_nombre_refaccion;
    private javax.swing.JLabel jL_precio_compra;
    private javax.swing.JLabel jL_precio_venta;
    private javax.swing.JLabel jL_titulo_refaccion;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField jTF_cantidad_Existencia;
    private javax.swing.JTextField jTF_descripcion;
    private javax.swing.JTextField jTF_id;
    private javax.swing.JTextField jTF_modelo_carro;
    private javax.swing.JTextField jTF_nombre_refaccion;
    private javax.swing.JTextField jTF_precio_compra;
    private javax.swing.JTextField jTF_precio_venta;
    // End of variables declaration//GEN-END:variables
}
