package ventanas;


import javax.swing.JOptionPane;


import java.sql.*;
public class servicios extends javax.swing.JFrame {

   
private Connection conexion;     
private Statement st;     
private ResultSet rs; 

public servicios() {
        initComponents();
        Conectar();
    }



                     public void Conectar(){

                     try{ 
                        conexion=DriverManager.getConnection("jdbc:mysql://localhost:3307/protaller","root","");                     
                        st=conexion.createStatement(); 

                        rs=st.executeQuery("Select * from servicios");             

                        rs.first(); 

            this.jTF_numero_servicio.setText(rs.getString("No_Servicio"));                         
                        
            this.jTF_precio.setText(rs.getString("Precio"));
            this.jTF_rfc.setText(rs.getString("RFC"));
            
                    }catch(SQLException err){ 
                         
                    } 

                }
                     private void siguienteRegistro(){    
                    try{            
                    if(rs.isLast()==false) {   
                     rs.next();               
                     this.jTF_numero_servicio.setText(rs.getString("No_Servicio")); 
                         
                         this.jTF_precio.setText(rs.getString("Precio"));
                         this.jTF_rfc.setText(rs.getString("RFC"));
             }        
            }catch(Exception err) {   
             }    
            }
                     private void anteriorRegistro(){    
                        try{            
     
                        rs.previous();               
                        this.jTF_numero_servicio.setText(rs.getString("No_Servicio")); 
                         
                         this.jTF_precio.setText(rs.getString("Precio"));
                         this.jTF_rfc.setText(rs.getString("RFC"));
            
                }catch(Exception err) { 
                
                 }
                }
                     
                        private void primerRegistro(){    
                        try{            
      
                        rs.first();               
                         this.jTF_numero_servicio.setText(rs.getString("No_Servicio")); 
                         
                         this.jTF_precio.setText(rs.getString("Precio"));
                         this.jTF_rfc.setText(rs.getString("RFC"));   
                         
                         }catch(Exception err) { 
                                      
                            }    
                     }
                   private void ultimoRegistro(){    
                        try{            
      
                        rs.last();               
                         this.jTF_numero_servicio.setText(rs.getString("No_Servicio")); 
                         
                         this.jTF_precio.setText(rs.getString("Precio"));
                         this.jTF_rfc.setText(rs.getString("RFC")); 
           
                     }catch(Exception err) { 
              
                     }    
                    }
                    private void registrarRegistro() {        
                     try{ 
                           
                       String numero_servicio=this.jTF_numero_servicio.getText(); 
                       String preventivo=this.jCB_preventivo.getSelectedItem().toString();
                       String precio=this.jTF_precio.getText();
                       String rfc=this.jTF_rfc.getText();
                   String sql="Insert into servicios (No_Servicio, Tipo, Precio, RFC)"+" values ('"+numero_servicio +"','"+preventivo+"','"+precio+"','"+rfc+"');";   
                   System.out.println(sql); 
                       
            st.executeUpdate(sql); 
            
         
            this.primerRegistro();

        } catch(SQLException err) { 
             
        } 

    }
                     private void borrarRegistro(){
                 try{ 
                    st.executeUpdate("delete from servicios where No_Servicio="+this.jTF_numero_servicio.getText());


                  } catch(SQLException err){ 
             
              } 

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jL_numero_servicio = new javax.swing.JLabel();
        jTF_numero_servicio = new javax.swing.JTextField();
        jL_tipo = new javax.swing.JLabel();
        jCB_preventivo = new javax.swing.JComboBox<>();
        jL_precio = new javax.swing.JLabel();
        jTF_precio = new javax.swing.JTextField();
        jB_registrar = new javax.swing.JButton();
        jB_limpiar = new javax.swing.JButton();
        jB_borrar = new javax.swing.JButton();
        jL_rfc = new javax.swing.JLabel();
        jTF_rfc = new javax.swing.JTextField();
        jB_primero = new javax.swing.JButton();
        jB_anterior = new javax.swing.JButton();
        jB_seguiente = new javax.swing.JButton();
        jB_ultimo = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jB_administrador = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(153, 153, 255));
        setForeground(new java.awt.Color(153, 153, 255));

        jPanel1.setBackground(new java.awt.Color(2, 0, 102));
        jPanel1.setForeground(new java.awt.Color(102, 204, 255));

        jLabel1.setBackground(new java.awt.Color(51, 204, 0));
        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Registro de Servicios");

        jL_numero_servicio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_numero_servicio.setForeground(new java.awt.Color(255, 255, 255));
        jL_numero_servicio.setText("No. Servicio");

        jTF_numero_servicio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_numero_servicio.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jTF_numero_servicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTF_numero_servicioActionPerformed(evt);
            }
        });

        jL_tipo.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_tipo.setForeground(new java.awt.Color(255, 255, 255));
        jL_tipo.setText("Tipo");

        jCB_preventivo.setBackground(new java.awt.Color(0, 0, 102));
        jCB_preventivo.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jCB_preventivo.setForeground(new java.awt.Color(255, 255, 255));
        jCB_preventivo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Preventivo", "Correctivo" }));
        jCB_preventivo.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));
        jCB_preventivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCB_preventivoActionPerformed(evt);
            }
        });

        jL_precio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_precio.setForeground(new java.awt.Color(255, 255, 255));
        jL_precio.setText("Precio");

        jTF_precio.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_precio.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_registrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_registrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_registrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_registrar.setText("Registrar");
        jB_registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_registrarActionPerformed(evt);
            }
        });

        jB_limpiar.setBackground(new java.awt.Color(0, 0, 51));
        jB_limpiar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_limpiar.setForeground(new java.awt.Color(255, 255, 255));
        jB_limpiar.setText("Limpiar");
        jB_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_limpiarActionPerformed(evt);
            }
        });

        jB_borrar.setBackground(new java.awt.Color(0, 0, 51));
        jB_borrar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_borrar.setForeground(new java.awt.Color(255, 255, 255));
        jB_borrar.setText("Borrar");
        jB_borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_borrarActionPerformed(evt);
            }
        });

        jL_rfc.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jL_rfc.setForeground(new java.awt.Color(255, 255, 255));
        jL_rfc.setText("RFC");

        jTF_rfc.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jTF_rfc.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(51, 0, 204)));

        jB_primero.setBackground(new java.awt.Color(0, 0, 51));
        jB_primero.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_primero.setForeground(new java.awt.Color(255, 255, 255));
        jB_primero.setText("|<");
        jB_primero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_primeroActionPerformed(evt);
            }
        });

        jB_anterior.setBackground(new java.awt.Color(0, 0, 51));
        jB_anterior.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_anterior.setForeground(new java.awt.Color(255, 255, 255));
        jB_anterior.setText("<<");
        jB_anterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_anteriorActionPerformed(evt);
            }
        });

        jB_seguiente.setBackground(new java.awt.Color(0, 0, 51));
        jB_seguiente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_seguiente.setForeground(new java.awt.Color(255, 255, 255));
        jB_seguiente.setText(">>");
        jB_seguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_seguienteActionPerformed(evt);
            }
        });

        jB_ultimo.setBackground(new java.awt.Color(0, 0, 51));
        jB_ultimo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jB_ultimo.setForeground(new java.awt.Color(255, 255, 255));
        jB_ultimo.setText(">|");
        jB_ultimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_ultimoActionPerformed(evt);
            }
        });

        jSeparator3.setBackground(new java.awt.Color(0, 51, 255));
        jSeparator3.setForeground(new java.awt.Color(51, 153, 255));
        jSeparator3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 102), new java.awt.Color(0, 0, 51), new java.awt.Color(0, 51, 255), new java.awt.Color(0, 0, 153)));

        jB_administrador.setBackground(new java.awt.Color(0, 0, 51));
        jB_administrador.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jB_administrador.setForeground(new java.awt.Color(255, 255, 255));
        jB_administrador.setText("Menú");
        jB_administrador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_administradorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator3)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jL_numero_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jL_tipo, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGap(10, 10, 10)
                                                    .addComponent(jL_rfc))
                                                .addComponent(jL_precio, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(63, 63, 63)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTF_rfc, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jTF_precio, javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jTF_numero_servicio, javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jCB_preventivo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jB_primero)
                                        .addGap(18, 18, 18)
                                        .addComponent(jB_anterior)
                                        .addGap(18, 18, 18)
                                        .addComponent(jB_seguiente)
                                        .addGap(18, 18, 18)
                                        .addComponent(jB_ultimo))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jB_limpiar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jB_borrar)
                                .addGap(18, 18, 18)
                                .addComponent(jB_registrar)))
                        .addGap(0, 12, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jB_administrador)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_numero_servicio)
                    .addComponent(jTF_numero_servicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_tipo)
                    .addComponent(jCB_preventivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_precio)
                    .addComponent(jTF_precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jL_rfc)
                    .addComponent(jTF_rfc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_primero)
                    .addComponent(jB_anterior)
                    .addComponent(jB_seguiente)
                    .addComponent(jB_ultimo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jB_limpiar)
                    .addComponent(jB_borrar)
                    .addComponent(jB_registrar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jB_administrador)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jB_registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_registrarActionPerformed
        registrarRegistro();      
            JOptionPane.showMessageDialog(this, "Registro Guardado");
// TODO add your handling code here:
    }//GEN-LAST:event_jB_registrarActionPerformed

    private void jB_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_limpiarActionPerformed
            this.jTF_numero_servicio.setText("");   
            this.jTF_precio.setText("");             
            this.jTF_rfc.setText("");
            
            
    }
            public void limpiarCajasTexto(){
                this.jTF_numero_servicio.setText("");                     
                this.jTF_precio.setText("");             
                this.jTF_rfc.setText("");
                
            // TODO add your handling code here:
    }//GEN-LAST:event_jB_limpiarActionPerformed

    private void jTF_numero_servicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTF_numero_servicioActionPerformed
       
        // TODO add your handling code here:
    }//GEN-LAST:event_jTF_numero_servicioActionPerformed

    private void jCB_preventivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCB_preventivoActionPerformed
            
       

// TODO add your handling code here:
    }//GEN-LAST:event_jCB_preventivoActionPerformed

    private void jB_borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_borrarActionPerformed

    borrarRegistro();        // TODO add your handling code here:
    JOptionPane.showMessageDialog(this, "¿Desea borrar el Registro?");
    JOptionPane.showMessageDialog(this, "¡Registro borrado!");
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_borrarActionPerformed

    private void jB_seguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_seguienteActionPerformed
        siguienteRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_seguienteActionPerformed

    private void jB_primeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_primeroActionPerformed
        primerRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_primeroActionPerformed

    private void jB_anteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_anteriorActionPerformed
    anteriorRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_anteriorActionPerformed

    private void jB_ultimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ultimoActionPerformed
            ultimoRegistro();
        // TODO add your handling code here:
    }//GEN-LAST:event_jB_ultimoActionPerformed

    private void jB_administradorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_administradorActionPerformed
        Administrador menu = new Administrador();
        menu.setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_jB_administradorActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new servicios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jB_administrador;
    private javax.swing.JButton jB_anterior;
    private javax.swing.JButton jB_borrar;
    private javax.swing.JButton jB_limpiar;
    private javax.swing.JButton jB_primero;
    private javax.swing.JButton jB_registrar;
    private javax.swing.JButton jB_seguiente;
    private javax.swing.JButton jB_ultimo;
    private javax.swing.JComboBox<String> jCB_preventivo;
    private javax.swing.JLabel jL_numero_servicio;
    private javax.swing.JLabel jL_precio;
    private javax.swing.JLabel jL_rfc;
    private javax.swing.JLabel jL_tipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTF_numero_servicio;
    private javax.swing.JTextField jTF_precio;
    private javax.swing.JTextField jTF_rfc;
    // End of variables declaration//GEN-END:variables
}
