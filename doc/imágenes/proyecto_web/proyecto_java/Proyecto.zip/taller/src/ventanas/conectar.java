


package ventanas;
/**
 *
 * @author Jireh Castillo
 */
import java.sql.*;

public class conectar {
    
    Connection cn;
    Statement st;
    
    public Connection Conexion(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost/protaller", "root", " ");
            System.out.print("Conexion establecida...");
        }catch (Exception e){
            System.out.print(e.getMessage());
        }return cn;
        }
    }

